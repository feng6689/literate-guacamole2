# -*- coding: utf-8 -*-
"""入口脚本 · 可视化阶段（部分接线）。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

IMPLEMENTATION_STATUS = "partial"

CALL_CHAIN = [
    "FP08 run_eda(bundle, 'outputs/figures')",
    "PCA/UMAP 投影 -> FP07 plot_decision_boundaries(...)",
    "报告汇总 -> outputs/reports/",
]


def main() -> None:
    for i, step in enumerate(CALL_CHAIN, 1):
        print(f"[viz] {i:02d}. {step}")
    print("[viz] 部分实现：绘图函数已可用，投影器与 Pipeline 的联调留待后续。")


if __name__ == "__main__":
    main()
