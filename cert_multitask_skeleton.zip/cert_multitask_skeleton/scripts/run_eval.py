# -*- coding: utf-8 -*-
"""入口脚本 · 评估阶段（部分接线）。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

IMPLEMENTATION_STATUS = "partial"

CALL_CHAIN = [
    "metrics.compute_metrics(y_true, y_pred, intervals)",
    "FP06 assign_risk_tiers + score_tiers",
    "FP10 grouped_permutation_importance + assert_noise_ranks_last",
    "FP12 plot_learning_curves + diagnose_bias_variance_drift",
    "FP13 detect_and_adapt_drift",
    "FP15 audit_fairness_feedback",
    "significance.paired_bootstrap / diebold_mariano",
    "reporting.ablation.collect_ablations + cards.build_model_card",
]


def main() -> None:
    for i, step in enumerate(CALL_CHAIN, 1):
        print(f"[eval] {i:02d}. {step}")
    print("[eval] 部分实现：指标计算函数已可用，全流程串联与阈值断言留待联调。")


if __name__ == "__main__":
    main()
