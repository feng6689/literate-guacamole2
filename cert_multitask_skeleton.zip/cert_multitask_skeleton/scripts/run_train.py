# -*- coding: utf-8 -*-
"""入口脚本 · 训练阶段（部分接线：给出调用链，张量对齐与错误恢复留待联调）。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

IMPLEMENTATION_STATUS = "partial"

CALL_CHAIN = [
    "FP03 fit_transform_skew(X_train, X_others)",
    "FP09 nested_target_encode(X, y, inner_folds, cfg)",
    "interaction_embedding.fit_embed_interactions(mat_train)",
    "FP11 build_leakage_safe_pipeline(estimator, cfg) + freeze_and_hash_params",
    "FP05 grid_search_knn(X, y, folds, cfg)",
    "FP01 fit_multioutput(X, y, {'joint': True})",
    "FP14 build_intervals / calibrate_intervals",
    "FP16 compare_and_stack + paired_significance",
]


def main() -> None:
    """逐阶段示意；完整联调需把各折的索引、编码映射与稀疏矩阵行对齐。"""
    for i, step in enumerate(CALL_CHAIN, 1):
        print(f"[train] {i:02d}. {step}")
    print("[train] 部分实现：未做端到端联调，也未实际执行训练。")


if __name__ == "__main__":
    main()
