# -*- coding: utf-8 -*-
"""入口脚本 · 数据阶段（部分接线，未做端到端联调）。"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cert_multitask.data.fp02_synthesize import synthesize_dataset
from cert_multitask.data.schema import load_schema, validate_tables
from cert_multitask.data.fp04_clean import clean_dataset, diagnose_missingness, sensitivity_analysis
from cert_multitask.data.split import build_walk_forward_splits, assert_group_disjoint

IMPLEMENTATION_STATUS = "partial"


def main() -> None:
    """FP02 -> schema 校验 -> FP04 -> 切分，数据层可实际串联。"""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    spec = load_schema(os.path.join(root, "configs", "data_spec.yaml"))
    bundle = synthesize_dataset(spec, seed=int(spec.get("seed", 42)))
    report = validate_tables({"enrollment": bundle["enrollment"],
                              "assessment": bundle["assessment"]}, spec)
    bundle = clean_dataset(bundle, spec)
    missing = diagnose_missingness(bundle["enrollment"])
    sens = sensitivity_analysis(bundle)
    cfg = {"min_train_terms": 3, "purge_gap_terms": 1}
    splits = build_walk_forward_splits(bundle["enrollment"], cfg)
    assert_group_disjoint(splits, "student_id")
    print(f"[data] rows={len(bundle['enrollment'])} retention={bundle['quality_report']['retention']:.3f} "
          f"folds={len(splits)} schema_pass={report['pass']}")
    print(f"[data] missing mechanisms:\n{missing.head(8).to_string(index=False)}")
    print(f"[data] sensitivity:\n{sens.to_string(index=False)}")


if __name__ == "__main__":
    main()
