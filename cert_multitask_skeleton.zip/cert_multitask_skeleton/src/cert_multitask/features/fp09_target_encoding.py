# -*- coding: utf-8 -*-
"""FP09 · 类别目标编码（折中折，部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

IMPLEMENTATION_STATUS = "partial"
CAT_COLS = ("motivation_level", "parental_education_tier")
MOTIVATION_ORDER = {"low": 0, "moderate": 1, "high": 2, "very_high": 3, "not_disclosed": -1}


def harmonize_scales(frame: pd.DataFrame, center_col: str = "center_id") -> pd.DataFrame:
    """对齐各中心动机量表口径：把 not_disclosed 与中心内极少数类别归并到中心众数。"""
    out = frame.copy()
    for _, idx in out.groupby(center_col).groups.items():
        sub = out.loc[idx, "motivation_level"]
        valid = sub[sub != "not_disclosed"]
        mode = valid.mode().iloc[0] if len(valid) else "moderate"
        out.loc[idx, "motivation_level"] = sub.replace({"not_disclosed": mode})
    return out


def _smooth_map(frame: pd.DataFrame, col: str, y: np.ndarray, idx: np.ndarray,
                global_mean: np.ndarray, m: float) -> pd.DataFrame:
    """按训练折统计计算平滑后的类别 -> 目标均值映射。"""
    tmp = pd.DataFrame({col: frame[col].iloc[idx].to_numpy()})
    for t in range(y.shape[1]):
        tmp[f"t{t}"] = y[idx, t]
    g = tmp.groupby(col, dropna=False).agg(["mean", "count"])
    maps = {}
    for t in range(y.shape[1]):
        mean, cnt = g[(f"t{t}", "mean")], g[(f"t{t}", "count")]
        maps[f"te_{col}_t{t}"] = ((cnt * mean + m * global_mean[t]) / (cnt + m)).to_dict()
    return pd.DataFrame(maps), global_mean


def nested_target_encode(X: pd.DataFrame, y: np.ndarray, folds: list[Any],
                         cfg: dict[str, Any] | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    """折中折 k 折目标编码：训练集用 OOF 编码，映射仅由折内统计产生。"""
    cfg = cfg or {}
    m = float(cfg.get("smoothing", 10.0))
    noise = float(cfg.get("noise_std", 0.01))
    rng = np.random.default_rng(int(cfg.get("seed", 42)))
    y = np.asarray(y, dtype=float)
    global_mean = np.nanmean(y, axis=0)
    out = X.drop(columns=list(CAT_COLS)).copy()
    mapping: dict[str, Any] = {"smoothing": m, "global_mean": global_mean.tolist(), "maps": {}}

    for col in CAT_COLS:
        for t in range(y.shape[1]):
            out[f"te_{col}_t{t}"] = global_mean[t]
        for tr, va in folds:
            tr, va = np.asarray(tr), np.asarray(va)
            maps, _ = _smooth_map(X, col, y, tr, global_mean, m)
            mapping["maps"][(col, int(tr[0]))] = maps
            for t in range(y.shape[1]):
                key = f"te_{col}_t{t}"
                vals = X[col].iloc[va].map(maps[key]).fillna(global_mean[t]).to_numpy(float)
                out.loc[out.index[va], key] = vals + rng.normal(0, noise, len(va))
    # 供 valid/test 使用的全训练折映射（逐类别分别计算）
    for c in CAT_COLS:
        maps_full, _ = _smooth_map(X, c, y, np.arange(len(X)), global_mean, m)
        mapping["maps"][("full", c)] = maps_full
    return out, mapping


def monotonic_ordinal_encode(series: pd.Series) -> pd.Series:
    """按有序语义做单调编码。"""
    return series.map(MOTIVATION_ORDER).fillna(-1).astype(float)


def assert_no_encoding_leakage(encoded: pd.DataFrame, raw: pd.DataFrame) -> None:
    """折内均值 vs 全量均值差异检验：若 OOF 编码恰好等于全量均值，说明发生了泄漏。"""
    te_cols = [c for c in encoded.columns if c.startswith("te_")]
    if not te_cols:
        raise AssertionError("未找到目标编码列")
    for c in te_cols[:2]:
        spread = float(encoded[c].std())
        if spread < 1e-8:
            raise AssertionError(f"{c} 编码无折间差异，疑似使用全量统计（泄漏）")
