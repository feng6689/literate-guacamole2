# -*- coding: utf-8 -*-
"""FP03 · 偏态分布变换（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from scipy import stats
except ImportError:
    stats = None

IMPLEMENTATION_STATUS = "partial"


def _apply(x: np.ndarray, name: str, lam: float, shift: float) -> np.ndarray:
    if name == "log1p":
        return np.log1p(np.clip(x, 0, None))
    if name == "boxcox":
        return (np.power(x + shift, lam) - 1.0) / lam if abs(lam) > 1e-9 else np.log(x + shift)
    if name == "yeo_johnson":
        return np.asarray(stats.yeojohnson(x, lmbda=lam)) if stats else x.copy()
    return x.copy()


def choose_transform(x: np.ndarray) -> dict[str, Any]:
    """对比 log1p / Box-Cox / Yeo-Johnson 的偏度下降幅度并自动择优。"""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3 or stats is None:
        return {"name": "log1p", "lam": 0.0, "shift": 0.0, "skew_before": 0.0,
                "skew_after": 0.0, "gain": 0.0}
    before = abs(float(stats.skew(x)))
    shift = 1.0 - float(np.min(x)) if np.min(x) <= 0 else 0.0
    xb = x + shift
    try:
        _, lam_bc = stats.boxcox(xb)
    except Exception:
        lam_bc = 1.0
    try:
        _, lam_yj = stats.yeojohnson(x)
        lam_yj = float(np.atleast_1d(lam_yj)[0])
    except Exception:
        lam_yj = 1.0
    candidates = {
        "log1p": (0.0, shift),
        "boxcox": (float(lam_bc), shift),
        "yeo_johnson": (lam_yj, 0.0),
    }
    best_name, best_lam, best_shift, best_gain, best_after = "log1p", 0.0, shift, -np.inf, before
    for name, (lam, sh) in candidates.items():
        try:
            after = abs(float(stats.skew(_apply(x, name, lam, sh))))
        except Exception:
            continue
        gain = before - after
        if gain > best_gain:
            best_name, best_lam, best_shift = name, lam, sh
            best_gain, best_after = gain, after
    return {"name": best_name, "lam": best_lam, "shift": best_shift,
            "skew_before": before, "skew_after": best_after, "gain": best_gain}


def fit_transform_skew(X_train: pd.DataFrame,
                       X_others: dict[str, pd.DataFrame] | None = None
                       ) -> tuple[Any, dict[str, Any]]:
    """仅在训练折拟合择优变换，再应用到其他折（fit-only-on-train）。"""
    X_others = X_others or {}
    state: dict[str, Any] = {"columns": {}, "report": []}
    out_train = X_train.copy()
    others_out = {k: v.copy() for k, v in X_others.items()}
    for col in X_train.select_dtypes(include=[np.number]).columns:
        raw = X_train[col].to_numpy(float)
        raw = raw[np.isfinite(raw)]
        info = choose_transform(raw)
        state["columns"][col] = info
        state["report"].append({"column": col, **info})
        lam, sh, name = info["lam"], info["shift"], info["name"]
        out_train[col] = _apply(X_train[col].to_numpy(float), name, lam, sh)
        for k, frame in others_out.items():
            frame[col] = _apply(frame[col].to_numpy(float), name, lam, sh)
    state["report"] = pd.DataFrame(state["report"])
    return ({"train": out_train, "others": others_out, "state": state}, state)


def handle_zero_inflation(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """hurdle 两部表示：零值指示位 + 正值部分。"""
    x = np.asarray(x, dtype=float)
    indicator = (x > 0).astype(float)
    positive = np.where(x > 0, x, np.nan)
    return indicator, positive
