# -*- coding: utf-8 -*-
"""FP11 · 泄漏防护 Pipeline（部分实现）。"""
from __future__ import annotations

import hashlib
import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
except ImportError:
    Pipeline = SimpleImputer = StandardScaler = None

IMPLEMENTATION_STATUS = "partial"


def build_leakage_safe_pipeline(estimator: Any, cfg: dict[str, Any] | None = None) -> Any:
    """插补 -> 缩放 -> 模型串成单一 Pipeline。

    部分实现：偏态变换 / 目标编码 / 稀疏降维已分别在 FP03、FP09、
    interaction_embedding 中按折拟合，此处通过 cfg['extra_steps'] 预留挂接点，
    完整串联需在各折循环中调用，未在单一 Pipeline 内重复实现。
    """
    if Pipeline is None:
        raise RuntimeError("需要 scikit-learn")
    cfg = cfg or {}
    steps = [
        ("imputer", SimpleImputer(strategy=cfg.get("impute_strategy", "median"), add_indicator=True)),
        ("scaler", StandardScaler()),
    ]
    steps.extend(cfg.get("extra_steps", []))
    steps.append(("model", estimator))
    return Pipeline(steps)


def freeze_and_hash_params(pipeline: Any) -> str:
    """对 fit 后的 get_params(deep=True) 做稳定哈希快照。"""
    params = pipeline.get_params(deep=True)
    parts = []
    for k in sorted(params):
        v = params[k]
        if isinstance(v, np.ndarray):
            v = np.asarray(v).round(8).tolist()
        parts.append(f"{k}={v!r}")
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()


def assert_params_frozen(pipeline: Any, before: str) -> None:
    """断言变换参数在训练拟合后被冻结（后续 transform 不得改写 mean_/scale_）。"""
    after = freeze_and_hash_params(pipeline)
    if after != before:
        raise AssertionError("预处理参数在 fit 之后发生了变化，存在测试集统计泄漏")
    scaler = pipeline.named_steps.get("scaler")
    if scaler is not None and hasattr(scaler, "n_samples_seen_"):
        # n_samples_seen_ 应等于训练样本数，不应因 transform 增长
        pass  # TODO(FP11): 完整实现需记录训练样本数并在此断言


def detect_injected_leakage(pipeline: Any, X_probe: Any) -> bool:
    """主动注入测试集统计量并检测报警：改写 scaler.mean_ 后应能被快照比对发现。"""
    scaler = pipeline.named_steps.get("scaler")
    if scaler is None or not hasattr(scaler, "mean_"):
        return False
    before_hash = freeze_and_hash_params(pipeline)
    original = np.asarray(scaler.mean_).copy()
    injected = np.nanmean(np.asarray(X_probe, dtype=float), axis=0)
    scaler.mean_ = injected[: len(original)]  # 模拟「用测试集均值覆盖训练统计量」
    alarm = freeze_and_hash_params(pipeline) != before_hash
    scaler.mean_ = original  # 复原，避免污染
    return bool(alarm)
