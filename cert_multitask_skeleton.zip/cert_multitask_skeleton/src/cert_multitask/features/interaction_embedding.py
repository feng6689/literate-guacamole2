# -*- coding: utf-8 -*-
"""FP01/FP02 · 稀疏交互矩阵降维与融合（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.decomposition import TruncatedSVD
except ImportError:
    TruncatedSVD = None

IMPLEMENTATION_STATUS = "partial"


def fit_embed_interactions(mat_train: Any, n_components: int = 16,
                           variance_target: float = 0.85) -> tuple[Any, Any]:
    """仅在训练折拟合 TruncatedSVD；按累计解释方差自动收缩成分数。"""
    if TruncatedSVD is None:
        raise RuntimeError("需要 scikit-learn")
    k = min(n_components, min(mat_train.shape) - 1)
    svd = TruncatedSVD(n_components=max(k, 1), random_state=42)
    emb = svd.fit_transform(mat_train)
    cum = np.cumsum(svd.explained_variance_ratio_)
    keep = int(np.searchsorted(cum, variance_target) + 1)
    return emb[:, :keep], {"svd": svd, "keep": keep, "cum_variance": cum[:keep].tolist()}


def fuse_features(structured: pd.DataFrame, embedded: np.ndarray) -> np.ndarray:
    """拼接结构化特征与交互成分；NaN 用训练折列中位数填充（此处按列中位数近似）。"""
    S = structured.select_dtypes(include=[np.number]).to_numpy(float)
    med = np.nanmedian(np.where(np.isfinite(S), S, np.nan), axis=0)
    S = np.where(np.isfinite(S), S, np.broadcast_to(med, S.shape))
    return np.hstack([S, np.asarray(embedded, dtype=float)])
