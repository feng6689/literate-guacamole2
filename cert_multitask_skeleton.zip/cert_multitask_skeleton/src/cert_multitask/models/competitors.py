# -*- coding: utf-8 -*-
"""FP16 · 对比模型占位（部分实现：全部用 sklearn 可获得的估计器近似）。"""
from __future__ import annotations

import numpy as np
from typing import Any

try:
    from sklearn.multioutput import MultiOutputRegressor
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.neural_network import MLPRegressor
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, WhiteKernel
except ImportError:
    MultiOutputRegressor = GradientBoostingRegressor = MLPRegressor = None
    GaussianProcessRegressor = RBF = WhiteKernel = None

IMPLEMENTATION_STATUS = "partial"


def build_competitors(cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """构造三类对比估计器。

    部分实现：GBDT 用 MultiOutputRegressor 包装、MTL-NN 用原生多输出 MLP、
    MO-GP 用每目标独立 GP 近似；xgboost / torch / gpytorch 的完整版本见 TODO。
    """
    cfg = cfg or {}
    return {
        "multioutput_gbdt": MultiOutputRegressor(
            GradientBoostingRegressor(n_estimators=int(cfg.get("gbdt_iters", 80)),
                                      max_depth=3, random_state=42)),
        "multitask_nn": MLPRegressor(hidden_layer_sizes=(64, 32), max_iter=int(cfg.get("nn_iters", 200)),
                                     random_state=42, early_stopping=True),
        "multioutput_gp": MultiOutputRegressor(
            GaussianProcessRegressor(kernel=RBF(1.0) + WhiteKernel(1.0),
                                     normalize_y=True, alpha=1e-2, random_state=42)),
    }


def fit_one(estimator: Any, X: np.ndarray, y: np.ndarray) -> Any:
    """统一训练接口：剔除右删失样本。"""
    mask = np.isfinite(y).all(axis=1)
    estimator.fit(np.asarray(X)[mask], np.asarray(y)[mask])
    return estimator
