# -*- coding: utf-8 -*-
"""models 包 · 项目骨架（无实现）。"""
