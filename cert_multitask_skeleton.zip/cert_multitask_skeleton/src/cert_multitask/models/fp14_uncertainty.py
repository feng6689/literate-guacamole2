# -*- coding: utf-8 -*-
"""FP14 · 不确定性量化与保序校准（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.isotonic import IsotonicRegression
except ImportError:
    IsotonicRegression = None

IMPLEMENTATION_STATUS = "partial"
COVERAGE_TARGET = (0.87, 0.93)


def build_intervals(model: Any, X: np.ndarray, y_cal: np.ndarray,
                    methods: list[str] | None = None) -> dict[str, Any]:
    """三选二产出候选 90% 区间：残差 bootstrap 与 conformal（分位数 KNN 见 TODO）。"""
    methods = methods or ["residual_bootstrap", "conformal"]
    point = model.predict(np.asarray(X)) if not isinstance(model, dict) else model["model"].predict(np.asarray(X))
    point = np.asarray(point, dtype=float)
    resid = np.asarray(y_cal, dtype=float) - point
    ok = np.isfinite(resid).all(axis=1)
    out: dict[str, Any] = {"point": point}
    if "residual_bootstrap" in methods:
        rng = np.random.default_rng(42)
        draws = np.array([np.quantile(resid[ok][rng.integers(0, ok.sum(), ok.sum())], [0.05, 0.95], axis=0)
                          for _ in range(200)])
        lo, hi = np.quantile(draws[:, 0], 0.1, axis=0), np.quantile(draws[:, 1], 0.9, axis=0)
        out["residual_bootstrap"] = (point + lo, point + hi)
    if "conformal" in methods:
        q = np.quantile(np.abs(resid[ok]), 0.90, axis=0)
        out["conformal"] = (point - q, point + q)
    return out


def calibrate_intervals(intervals: dict[str, Any], y_cal: np.ndarray) -> dict[str, Any]:
    """用保序回归把标称覆盖率映射到实际覆盖率，并据此缩放区间半宽。

    部分实现：以「目标覆盖率 / 经验覆盖率」的缩放因子近似保序校准，
    完整的分位数保序回归校准见 TODO。
    """
    y = np.asarray(y_cal, dtype=float)
    target = float(np.mean(COVERAGE_TARGET))
    out = dict(intervals)
    for key in ("residual_bootstrap", "conformal"):
        if key not in intervals:
            continue
        lo, hi = intervals[key]
        ok = np.isfinite(y)
        empirical = float(np.mean((y >= lo) & (y <= hi) & ok)) if ok.any() else 0.0
        factor = np.clip(target / max(empirical, 1e-3), 0.5, 2.0)
        center = (lo + hi) / 2
        half = (hi - lo) / 2 * factor
        out[key] = (center - half, center + half)
        out[f"{key}__empirical_coverage"] = empirical
        out[f"{key}__scale"] = factor
    return out


def score_intervals(intervals: dict[str, Any], y_true: np.ndarray) -> pd.DataFrame:
    """计算覆盖率、pinball loss 与区间宽度–误差相关性。"""
    y = np.asarray(y_true, dtype=float)
    rows = []
    point = np.asarray(intervals["point"])
    for key in ("residual_bootstrap", "conformal"):
        if key not in intervals:
            continue
        lo, hi = intervals[key]
        ok = np.isfinite(y).all(axis=1)
        cover = np.mean((y[ok] >= lo[ok]) & (y[ok] <= hi[ok]))
        width = np.mean(hi[ok] - lo[ok])
        err = np.abs(y[ok] - point[ok]).mean(axis=1)
        w = (hi[ok] - lo[ok]).mean(axis=1)
        corr = float(np.corrcoef(w, err)[0, 1]) if np.std(w) > 0 else 0.0
        q = 0.05
        pinball = float(np.mean(np.maximum(q * (y[ok] - lo[ok]), (q - 1) * (y[ok] - lo[ok]))))
        rows.append({"method": key, "coverage": float(cover), "mean_width": float(width),
                     "pinball_loss": pinball, "width_error_corr": corr})
    return pd.DataFrame(rows)
