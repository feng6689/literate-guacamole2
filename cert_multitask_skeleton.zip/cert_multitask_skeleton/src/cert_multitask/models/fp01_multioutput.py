# -*- coding: utf-8 -*-
"""FP01 · 表格多输出回归主流水线（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.base import clone
    from sklearn.multioutput import MultiOutputRegressor, RegressorChain
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.metrics import r2_score
except ImportError:
    clone = MultiOutputRegressor = RegressorChain = KNeighborsRegressor = r2_score = None

IMPLEMENTATION_STATUS = "partial"
TARGETS = ("written_exam_score", "practical_assessment_score")


def fit_multioutput(X: np.ndarray, y: np.ndarray, cfg: dict[str, Any] | None = None) -> Any:
    """联合训练两个输出，并用训练残差的 90% 分位数构造区间半宽。

    部分实现：用 MultiOutputRegressor / RegressorChain 近似「目标间相关结构建模」；
    完整的多输出高斯过程与联合损失训练见 competitors.py 与 TODO。
    """
    cfg = cfg or {}
    base = cfg.get("estimator") or KNeighborsRegressor(n_neighbors=11, weights="distance")
    if cfg.get("joint", True):
        model = RegressorChain(base, order=cfg.get("chain_order", [0, 1]))
    else:
        model = MultiOutputRegressor(base)
    mask = np.isfinite(y).all(axis=1)  # 右删失样本不参与训练
    model.fit(np.asarray(X)[mask], np.asarray(y)[mask])
    resid = np.asarray(y)[mask] - model.predict(np.asarray(X)[mask])
    half_width = np.quantile(np.abs(resid), 0.90, axis=0)
    corr = np.corrcoef(resid, rowvar=False)
    return {"model": model, "half_width": half_width, "residual_corr": corr,
            "n_train": int(mask.sum()), "cfg": cfg}


def predict_multioutput(model: Any, X: np.ndarray) -> dict[str, Any]:
    """同时返回两个点预测与各自的 90% 区间。"""
    if isinstance(model, dict):
        point = model["model"].predict(np.asarray(X))
        hw = np.asarray(model["half_width"])
    else:
        point = model.predict(np.asarray(X))
        hw = np.zeros(point.shape[1])
    return {"point": np.asarray(point), "lower": np.asarray(point) - hw,
            "upper": np.asarray(point) + hw,
            "written_exam_score": np.asarray(point)[:, 0],
            "practical_assessment_score": np.asarray(point)[:, 1]}


def ablate_vs_independent(X: np.ndarray, y: np.ndarray) -> pd.DataFrame:
    """对比联合建模与两个独立单输出模型。"""
    mask = np.isfinite(y).all(axis=1)
    X, y = np.asarray(X)[mask], np.asarray(y)[mask]
    rows = []
    joint = fit_multioutput(X, y, {"joint": True})
    pj = predict_multioutput(joint, X)["point"]
    for t, name in enumerate(TARGETS):
        rows.append({"setting": "joint", "target": name, "r2": float(r2_score(y[:, t], pj[:, t]))})
    base = KNeighborsRegressor(n_neighbors=11, weights="distance")
    for t, name in enumerate(TARGETS):
        m = clone(base).fit(X, y[:, t])
        rows.append({"setting": "independent", "target": name,
                     "r2": float(r2_score(y[:, t], m.predict(X)))})
    return pd.DataFrame(rows)
