# -*- coding: utf-8 -*-
"""FP16 · 模型对比、堆叠与可复现交付（部分实现）。"""
from __future__ import annotations

import json
import os
import numpy as np
import pandas as pd
from typing import Any

from cert_multitask.evaluation.significance import paired_bootstrap, diebold_mariano

IMPLEMENTATION_STATUS = "partial"


def compare_and_stack(predictions: dict[str, Any], y_true: np.ndarray,
                      cfg: dict[str, Any] | None = None) -> tuple[Any, pd.DataFrame]:
    """按 inverse-MAE 加权做简单堆叠，并输出对比表。

    部分实现：堆叠用凸组合权重而非带元学习器的 StackingRegressor；
    完整实现需在各折内 OOF 训练元学习器以避免泄漏。
    """
    y = np.asarray(y_true, dtype=float)
    ok = np.isfinite(y).all(axis=1)
    rows, weights = [], {}
    for name, p in predictions.items():
        p = np.asarray(p, dtype=float)[ok]
        mae = float(np.mean(np.abs(y[ok] - p)))
        weights[name] = 1.0 / (mae + 1e-6)
        rows.append({"model": name, "mae": mae,
                     "r2": float(1 - np.sum((y[ok] - p) ** 2) / np.sum((y[ok] - y[ok].mean(axis=0)) ** 2))})
    total = sum(weights.values())
    weights = {k: v / total for k, v in weights.items()}
    stacked = sum(w * np.asarray(predictions[k], dtype=float) for k, w in weights.items())
    rows.append({"model": "stack", "mae": float(np.mean(np.abs(y[ok] - stacked[ok]))),
                 "r2": float(1 - np.sum((y[ok] - stacked[ok]) ** 2) / np.sum((y[ok] - y[ok].mean(axis=0)) ** 2))})
    return {"weights": weights, "predict_fn": lambda X: None,  # 占位：推理需绑定基模型
            "stacked_oof": stacked}, pd.DataFrame(rows)


def paired_significance(pred_a: np.ndarray, pred_b: np.ndarray,
                        y: np.ndarray) -> dict[str, Any]:
    """配对 bootstrap 与 DM 检验。"""
    ea = np.abs(np.asarray(y) - np.asarray(pred_a)).mean(axis=1)
    eb = np.abs(np.asarray(y) - np.asarray(pred_b)).mean(axis=1)
    return {"bootstrap": paired_bootstrap(ea, eb), "dm": diebold_mariano(ea, eb)}


def write_repro_bundle(outdir: str, cfg: dict[str, Any]) -> None:
    """输出数据卡、模型卡、依赖锁与训练耗时。"""
    os.makedirs(outdir, exist_ok=True)
    payload = {
        "seed": cfg.get("seed", 42),
        "split": cfg.get("split", "walk_forward_grouped"),
        "metrics_threshold": cfg.get("metrics", {}),
        "model_card": {"intended_use": "考评前多输出成绩预测与资源排序",
                       "limitations": ["右删失样本不参与训练", "部分实现，未做端到端联调"]},
        "data_card": {"n_records": 3898, "n_unique_students": 1400,
                      "censoring": "written_exam_score 约 5% 右删失",
                      "rater_bias": "practical_assessment_score 含 3 名考评员系统偏差"},
    }
    with open(os.path.join(outdir, "repro_bundle.json"), "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
