# -*- coding: utf-8 -*-
"""FP05 · KNN 基线与距离度量学习（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.neighbors import KNeighborsRegressor
    from sklearn.metrics import mean_absolute_error, r2_score
except ImportError:
    KNeighborsRegressor = mean_absolute_error = r2_score = None

IMPLEMENTATION_STATUS = "partial"
K_GRID = (3, 5, 7, 11, 15, 21)
DISTANCES = ("euclidean", "manhattan", "mahalanobis", "cosine")
WEIGHTS = ("uniform", "distance")


def learn_metric(X_train: np.ndarray, y_train: np.ndarray) -> np.ndarray:
    """训练折上的对角马氏矩阵（方差倒数 × 与目标的相关加权）。

    部分实现：只学对角权重，完整马氏矩阵 / LMNN 度量学习留待后续。
    """
    X = np.asarray(X_train, dtype=float)
    var = np.nanvar(X, axis=0) + 1e-6
    y = np.nan_to_num(np.asarray(y_train, dtype=float)).mean(axis=1)
    corr = np.array([abs(np.corrcoef(np.nan_to_num(X[:, j]), y)[0, 1])
                     if np.std(X[:, j]) > 0 else 0.0 for j in range(X.shape[1])])
    corr = np.nan_to_num(corr)
    w = (1.0 / var) * (1.0 + corr)
    return np.diag(w / (w.mean() + 1e-9))


def grid_search_knn(X: np.ndarray, y: np.ndarray, folds: list[Any],
                    cfg: dict[str, Any] | None = None) -> tuple[Any, pd.DataFrame]:
    """嵌套时序分组 CV 网格搜索。

    部分实现：为控制篇幅，每个组合只在前 2 个外层折上评估，置信区间由折间
    bootstrap 近似；完整实现应遍历全部折并做配对显著性检验。
    """
    cfg = cfg or {}
    X, y = np.asarray(X, dtype=float), np.asarray(y, dtype=float)
    V = learn_metric(X, y)
    rows = []
    used = folds[:2]
    for k in cfg.get("k", K_GRID):
        for dist in cfg.get("distances", DISTANCES):
            for weight in cfg.get("weights", WEIGHTS):
                maes, r2s = [], []
                for tr, va in used:
                    tr, va = np.asarray(tr), np.asarray(va)
                    mask = np.isfinite(y[tr]).all(axis=1)
                    kw = {"n_neighbors": int(k), "metric": dist, "weights": weight}
                    if dist == "mahalanobis":
                        kw["metric_params"] = {"V": V}
                    m = KNeighborsRegressor(**kw).fit(X[tr][mask], y[tr][mask])
                    p = m.predict(X[va])
                    ok = np.isfinite(y[va]).all(axis=1)
                    maes.append(float(mean_absolute_error(y[va][ok], p[ok])))
                    r2s.append(float(r2_score(y[va][ok], p[ok], multioutput="uniform_average")))
                rows.append({"k": k, "distance": dist, "weights": weight,
                             "mae": float(np.mean(maes)), "mae_ci": float(1.96 * np.std(maes) / np.sqrt(len(maes) + 1e-9)),
                             "r2": float(np.mean(r2s)), "r2_ci": float(1.96 * np.std(r2s) / np.sqrt(len(r2s) + 1e-9))})
    results = pd.DataFrame(rows).sort_values("r2", ascending=False).reset_index(drop=True)
    best = results.iloc[0].to_dict()
    return best, results


def diagnose_curse_of_dimensionality(X: np.ndarray, results: pd.DataFrame) -> dict[str, Any]:
    """按维度子空间计算距离对比度，定量说明高维下的距离退化。"""
    X = np.asarray(X, dtype=float)
    rng = np.random.default_rng(42)
    sample = X[rng.choice(len(X), min(300, len(X)), replace=False)]
    out = {}
    for d in [2, 5, 10, min(20, X.shape[1]), X.shape[1]]:
        sub = sample[:, :d]
        D = np.linalg.norm(sub[:, None, :] - sub[None, :, :], axis=2)
        iu = np.triu_indices_from(D, k=1)
        vals = D[iu]
        out[f"d={d}"] = {"contrast": float((vals.max() - vals.min()) / (vals.mean() + 1e-9)),
                         "mean_dist": float(vals.mean())}
    return {"subspace": out,
            "note": "对比度随维度下降即维数灾难；KNN 应配合度量学习与稀疏降维",
            "best_r2": float(results["r2"].max()) if len(results) else None}
