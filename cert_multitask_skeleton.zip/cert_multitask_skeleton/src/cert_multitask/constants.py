# -*- coding: utf-8 -*-
"""全局常量：列名、目标、分组键、受保护属性与陷阱列（规格值，非实现）。"""
from __future__ import annotations

TARGETS = ("written_exam_score", "practical_assessment_score")

NUMERIC_FEATURES = (
    "weekly_study_hours", "attendance_rate", "prior_term_grade",
    "tutoring_sessions_count", "sleep_hours_avg", "extracurricular_hours",
    "commute_time_minutes", "random_id_noise",
)
CATEGORICAL_FEATURES = ("motivation_level", "parental_education_tier")
SKEW_CANDIDATES = ("tutoring_sessions_count", "commute_time_minutes")
ZERO_INFLATED = ("tutoring_sessions_count",)

GROUP_KEY = "student_id"
CENTER_KEY = "center_id"
TIME_KEY = "term_id"
COHORT_KEY = "cohort_id"
PROTECTED_ATTRS = ("parental_education_tier", "center_id")

TRAP_FEATURES = ("random_id_noise", "legacy_bias_index")
FORBIDDEN_FEATURES = ("rater_id", "scored_at", "retake_score", "post_exam_survey")
MOTIVATION_LEVELS = ("low", "moderate", "high", "very_high", "not_disclosed")
EDU_TIERS = ("none", "secondary", "vocational", "undergraduate", "postgraduate")
