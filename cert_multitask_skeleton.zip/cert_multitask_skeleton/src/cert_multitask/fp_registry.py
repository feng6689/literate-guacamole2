# -*- coding: utf-8 -*-
"""FP01-FP16 注册表：编号 -> 骨架文件 -> 入口函数 -> 验收标准。

本文件只含规格数据，不含实现；tests/test_fp_coverage.py 依据它检查骨架齐全性。
"""
from __future__ import annotations

FP_REGISTRY: dict[str, dict[str, str]] = {
    "FP01": {
        "module": "src/cert_multitask/models/fp01_multioutput.py",
        "entry": "fit_multioutput",
        "accept": "2 个点预测 + 2 组 90% 区间；联合建模消融优于两个单输出模型",
    },
    "FP02": {
        "module": "src/cert_multitask/data/fp02_synthesize.py",
        "entry": "synthesize_dataset",
        "accept": "3898 行面板 + 三源表 + 密度<6% 交互矩阵；四层生成复杂度可复现",
    },
    "FP03": {
        "module": "src/cert_multitask/features/fp03_skew_transform.py",
        "entry": "fit_transform_skew",
        "accept": "log1p/Box-Cox/Yeo-Johnson 按偏度下降自动择优；零膨胀单独处理",
    },
    "FP04": {
        "module": "src/cert_multitask/data/fp04_clean.py",
        "entry": "clean_dataset",
        "accept": "保留率 >= 97%；MNAR 不删行；缺失机制诊断 + 敏感性分析",
    },
    "FP05": {
        "module": "src/cert_multitask/models/fp05_knn.py",
        "entry": "grid_search_knn",
        "accept": "k∈{3,5,7,11,15,21} × 4 种距离 + 度量学习；嵌套时序分组 CV",
    },
    "FP06": {
        "module": "src/cert_multitask/evaluation/fp06_risk_tiers.py",
        "entry": "assign_risk_tiers",
        "accept": "4 级分层（含高风险高不确定）；ARI >= 0.72 + 二次加权 Kappa",
    },
    "FP07": {
        "module": "src/cert_multitask/visualization/fp07_boundaries.py",
        "entry": "plot_decision_boundaries",
        "accept": "两目标各一图：决策区域 + 散点 + 不确定性等值线 + 漂移区",
    },
    "FP08": {
        "module": "src/cert_multitask/visualization/fp08_eda.py",
        "entry": "run_eda",
        "accept": "直方图/箱线图/Q-Q/缺失矩阵/分面分布/三对照热力图 + 偏见审计图",
    },
    "FP09": {
        "module": "src/cert_multitask/features/fp09_target_encoding.py",
        "entry": "nested_target_encode",
        "accept": "折中折 k 折编码 + 平滑噪声 + 量表 harmonize + 无泄漏检验",
    },
    "FP10": {
        "module": "src/cert_multitask/evaluation/fp10_permutation.py",
        "entry": "grouped_permutation_importance",
        "accept": "整组置换 + bootstrap 置信区间；两个陷阱列排末两位且各 <= 2%",
    },
    "FP11": {
        "module": "src/cert_multitask/features/fp11_pipeline.py",
        "entry": "build_leakage_safe_pipeline",
        "accept": "单一 Pipeline 逐折 fit；参数快照哈希冻结；主动注入泄漏检测",
    },
    "FP12": {
        "module": "src/cert_multitask/evaluation/fp12_learning_curve.py",
        "entry": "plot_learning_curves",
        "accept": "按唯一学员数 + 留一中心 + 滚动学期三条曲线；偏差/方差/漂移诊断",
    },
    "FP13": {
        "module": "src/cert_multitask/evaluation/fp13_drift.py",
        "entry": "detect_and_adapt_drift",
        "accept": "MMD/PSI 量化；重加权/CORAL/增量微调；漂移集 R² 衰减 <= 0.04",
    },
    "FP14": {
        "module": "src/cert_multitask/models/fp14_uncertainty.py",
        "entry": "calibrate_intervals",
        "accept": "分位数 KNN/residual bootstrap/conformal 三选二；保序校准覆盖率 0.87-0.93",
    },
    "FP15": {
        "module": "src/cert_multitask/evaluation/fp15_fairness.py",
        "entry": "audit_fairness_feedback",
        "accept": "子群 R² 差 <= 0.03、MAE 差 <= 1.5；两轮反馈回路仿真",
    },
    "FP16": {
        "module": "src/cert_multitask/models/fp16_compare_stacking.py",
        "entry": "compare_and_stack",
        "accept": "KNN 基线 vs GBDT/MTL-NN/MO-GP；堆叠 + 配对 bootstrap p < 0.01",
    },
}

FP_ORDER = tuple(FP_REGISTRY)
