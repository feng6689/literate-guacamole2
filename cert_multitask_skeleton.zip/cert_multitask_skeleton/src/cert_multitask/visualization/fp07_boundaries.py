# -*- coding: utf-8 -*-
"""FP07 · 决策边界可视化（部分实现）。"""
from __future__ import annotations

import os
import numpy as np
import pandas as pd
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    from sklearn.decomposition import PCA
    from sklearn.neighbors import KNeighborsRegressor
except ImportError:
    PCA = KNeighborsRegressor = None

IMPLEMENTATION_STATUS = "partial"
TARGETS = ("written_exam_score", "practical_assessment_score")


def highlight_drift_region(ax: Any, X_2d: np.ndarray, centers: np.ndarray,
                           new_center_from: int = 5) -> None:
    """高亮新增中心（FP13 的漂移域）样本。"""
    if centers is None:
        return
    m = np.asarray(centers) >= new_center_from
    if m.any():
        ax.scatter(X_2d[m, 0], X_2d[m, 1], s=18, facecolors="none",
                   edgecolors="black", linewidths=0.8, marker="s", label="新增中心(漂移域)")
        ax.legend(loc="lower right", fontsize=7)


def plot_decision_boundaries(X_2d: np.ndarray, model: Any, y_pred: np.ndarray,
                             lower: np.ndarray, centers: Any = None,
                             outdir: str = "outputs/figures",
                             targets: Any = TARGETS) -> list[str]:
    """两目标各一张：KNN 决策区域 + 真实散点 + 不确定性等值线 + 漂移区高亮。

    部分实现：在二维投影上重训 KNN 仅用于可视化（不代表评估性能）；
    完整实现应把投影器也纳入 Pipeline 并在每个滚动折内拟合。
    """
    if PCA is None:
        raise RuntimeError("需要 scikit-learn")
    os.makedirs(outdir, exist_ok=True)
    X = np.asarray(X_2d, float)
    p = np.asarray(y_pred, float)
    lo = np.asarray(lower, float)
    width = np.clip((p - lo).mean(axis=1), 0, None)
    x0, x1 = X[:, 0].min(), X[:, 0].max()
    y0, y1 = X[:, 1].min(), X[:, 1].max()
    gx, gy = np.meshgrid(np.linspace(x0, x1, 60), np.linspace(y0, y1, 60))
    grid = np.column_stack([gx.ravel(), gy.ravel()])
    paths = []
    for t, name in enumerate(targets):
        knn2d = KNeighborsRegressor(n_neighbors=11, weights="distance").fit(X, p[:, t])
        z = knn2d.predict(grid).reshape(gx.shape)
        fig, ax = plt.subplots(figsize=(7, 5))
        cf = ax.contourf(gx, gy, z, levels=12, cmap="RdYlBu_r", alpha=0.65)
        sc = ax.scatter(X[:, 0], X[:, 1], c=p[:, t], cmap="viridis", s=12,
                        edgecolors="white", linewidths=0.2)
        try:
            ax.tricontour(X[:, 0], X[:, 1], width, levels=4,
                          colors="black", linewidths=0.6, alpha=0.7)
        except Exception:
            pass  # 共线样本无法三角剖分时跳过不确定性等值线
        highlight_drift_region(ax, X, centers)
        fig.colorbar(cf, ax=ax, label="KNN 决策面")
        fig.colorbar(sc, ax=ax, label=f"{name} 预测分")
        ax.set_title(f"FP07 决策边界 · {name}")
        ax.set_xlabel("PC1 / UMAP1")
        ax.set_ylabel("PC2 / UMAP2")
        out = os.path.join(outdir, f"fp07_boundary_{name}.png")
        fig.tight_layout()
        fig.savefig(out, dpi=110)
        plt.close(fig)
        paths.append(out)
    return paths
