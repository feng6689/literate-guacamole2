# -*- coding: utf-8 -*-
"""FP08 · EDA 分布与模式分析（部分实现）。"""
from __future__ import annotations

import os
import numpy as np
import pandas as pd
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    import seaborn as sns
except ImportError:
    sns = None
try:
    from scipy import stats
    from sklearn.feature_selection import mutual_info_regression
except ImportError:
    stats = mutual_info_regression = None

IMPLEMENTATION_STATUS = "partial"


def plot_bias_audit(frame: pd.DataFrame, attr_col: str = "parental_education_tier",
                    outdir: str = "outputs/figures") -> str:
    """绘制 legacy_bias_index 与各子群的相关性审计图。"""
    os.makedirs(outdir, exist_ok=True)
    fig, ax = plt.subplots(figsize=(7, 4))
    if attr_col in frame.columns and sns is not None:
        sns.boxplot(data=frame, x=attr_col, y="legacy_bias_index", ax=ax)
        ax.tick_params(axis="x", rotation=30)
    else:
        ax.hist(frame["legacy_bias_index"].dropna(), bins=25)
    ax.set_title("历史投放指数分布审计（按受保护属性分组）")
    out = os.path.join(outdir, "fp08_bias_audit.png")
    fig.tight_layout()
    fig.savefig(out, dpi=110)
    plt.close(fig)
    return out


def run_eda(bundle: dict[str, Any], outdir: str = "outputs/figures") -> dict[str, Any]:
    """直方图 / 箱线图 / Q-Q 图 / 缺失矩阵 / 分面分布 / 三对照热力图。"""
    os.makedirs(outdir, exist_ok=True)
    df = bundle["enrollment"].copy()
    assess = bundle["assessment"].copy()
    num = df.select_dtypes(include=[np.number]).columns.tolist()
    paths: dict[str, Any] = {}

    # 直方图 + 箱线图
    fig, axes = plt.subplots(2, 1, figsize=(10, 7))
    df[num[:6]].hist(ax=axes[0], bins=25)
    df[num[:6]].plot.box(ax=axes[1], rot=30)
    axes[0].set_title("FP08 数值特征直方图")
    axes[1].set_title("FP08 箱线图（离群点）")
    fig.tight_layout()
    paths["hist_box"] = os.path.join(outdir, "fp08_hist_box.png")
    fig.savefig(paths["hist_box"], dpi=110)
    plt.close(fig)

    # Q-Q 图（以右偏特征为例）
    fig, ax = plt.subplots(figsize=(5, 4))
    col = "commute_time_minutes" if "commute_time_minutes" in df else num[0]
    if stats is not None:
        stats.probplot(df[col].dropna(), dist="norm", plot=ax)
    ax.set_title(f"Q-Q: {col}")
    fig.tight_layout()
    paths["qq"] = os.path.join(outdir, "fp08_qq.png")
    fig.savefig(paths["qq"], dpi=110)
    plt.close(fig)

    # 缺失模式矩阵 + MNAR 检验摘要
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.imshow(df[num].isna().to_numpy().T, aspect="auto", cmap="Greys")
    ax.set_yticks(range(len(num)))
    ax.set_yticklabels(num, fontsize=6)
    ax.set_title("FP08 缺失模式矩阵")
    fig.tight_layout()
    paths["missing"] = os.path.join(outdir, "fp08_missing_matrix.png")
    fig.savefig(paths["missing"], dpi=110)
    plt.close(fig)

    # 分面分布：按 center_id 的自习时长
    if "center_id" in df.columns:
        fig, ax = plt.subplots(figsize=(7, 4))
        for c, sub in df.groupby("center_id"):
            ax.hist(sub["weekly_study_hours"].dropna(), bins=20, alpha=0.35, label=f"center {c}")
        ax.legend(fontsize=7)
        ax.set_title("FP08 分面分布：各中心自习时长")
        fig.tight_layout()
        paths["facet"] = os.path.join(outdir, "fp08_facet.png")
        fig.savefig(paths["facet"], dpi=110)
        plt.close(fig)

    # 三对照热力图：Pearson / Spearman / 互信息近似
    clean = df[num].replace([np.inf, -np.inf], np.nan).dropna()
    corrs = {"pearson": clean.corr().abs(), "spearman": clean.corr(method="spearman").abs()}
    if mutual_info_regression is not None and len(clean) > 20:
        mi = mutual_info_regression(clean.to_numpy(), clean.iloc[:, 0].to_numpy(), random_state=42)
        corrs["mutual_info"] = pd.DataFrame(np.abs(mi)[:, None], index=clean.columns, columns=["MI"])
    fig, axes = plt.subplots(1, len(corrs), figsize=(4 * len(corrs), 4))
    axes = np.atleast_1d(axes)
    for ax, (name, mat) in zip(axes, corrs.items()):
        im = ax.imshow(np.asarray(mat, float), cmap="magma")
        ax.set_title(name)
        fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    paths["heatmap"] = os.path.join(outdir, "fp08_heatmap.png")
    fig.savefig(paths["heatmap"], dpi=110)
    plt.close(fig)

    paths["bias_audit"] = plot_bias_audit(df, outdir=outdir)
    paths["summary"] = pd.concat([
        df[num].describe().T,
        assess[["written_exam_score", "practical_assessment_score"]].describe().T,
    ]).to_dict()
    return paths
