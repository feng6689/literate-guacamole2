# -*- coding: utf-8 -*-
"""FP10 · 分组置换重要性（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

from cert_multitask.evaluation.metrics import joint_r2

IMPLEMENTATION_STATUS = "partial"
TRAP_COLUMNS = ("random_id_noise", "legacy_bias_index")
MAX_TRAP_IMPORTANCE = 0.02


def _permute_by_group(x: np.ndarray, groups: np.ndarray, rng: Any) -> np.ndarray:
    """组内循环移位：保持组内结构与边缘分布，只切断该列与目标的对应。"""
    out = x.copy()
    for g in np.unique(groups):
        idx = np.flatnonzero(groups == g)
        if len(idx) > 1:
            out[idx] = np.roll(x[idx], rng.integers(1, len(idx)))
    return out


def grouped_permutation_importance(model: Any, X: np.ndarray, y: np.ndarray,
                                   groups: np.ndarray, n_repeats: int = 10,
                                   feature_names: list[str] | None = None) -> pd.DataFrame:
    """整组置换重要性 + bootstrap 置信区间。"""
    rng = np.random.default_rng(42)
    X, y = np.asarray(X, float), np.asarray(y, float)
    groups = np.asarray(groups)
    names = feature_names or [f"f{j}" for j in range(X.shape[1])]
    ok = np.isfinite(y).all(axis=1)
    base = joint_r2(y[ok], model.predict(X[ok]))
    rows = []
    for j, name in enumerate(names):
        drops = []
        for _ in range(n_repeats):
            Xp = X.copy()
            Xp[:, j] = _permute_by_group(X[:, j], groups, rng)
            drops.append(base - joint_r2(y[ok], model.predict(Xp[ok])))
        drops = np.asarray(drops)
        rows.append({"feature": name, "importance": float(drops.mean()),
                     "ci_low": float(np.quantile(drops, 0.025)),
                     "ci_high": float(np.quantile(drops, 0.975))})
    df = pd.DataFrame(rows).sort_values("importance", ascending=False).reset_index(drop=True)
    total = df["importance"].clip(lower=0).sum()
    df["importance_norm"] = df["importance"].clip(lower=0) / (total + 1e-12)
    df["rank"] = np.arange(1, len(df) + 1)
    return df


def assert_noise_ranks_last(importance: pd.DataFrame) -> None:
    """断言两个陷阱列排末两位且归一化重要性各 <= 2%。"""
    tail = set(importance.tail(2)["feature"])
    if not set(TRAP_COLUMNS).issubset(tail):
        raise AssertionError(f"陷阱列未排末两位: {tail}")
    for c in TRAP_COLUMNS:
        v = float(importance.loc[importance["feature"] == c, "importance_norm"].iloc[0])
        if v > MAX_TRAP_IMPORTANCE:
            raise AssertionError(f"{c} 重要性 {v:.4f} 超过 {MAX_TRAP_IMPORTANCE}")


def ablate_trap_columns(model: Any, X: np.ndarray, y: np.ndarray,
                        feature_names: list[str] | None = None) -> pd.DataFrame:
    """去掉陷阱列后重训并对比性能（部分实现：clone 后重拟合）。"""
    from sklearn.base import clone
    names = feature_names or [f"f{j}" for j in range(X.shape[1])]
    keep = [j for j, n in enumerate(names) if n not in TRAP_COLUMNS]
    ok = np.isfinite(y).all(axis=1)
    full = joint_r2(y[ok], model.predict(X[ok]))
    m = clone(model).fit(X[ok][:, keep], y[ok])
    reduced = joint_r2(y[ok], m.predict(X[ok][:, keep]))
    return pd.DataFrame([{"setting": "full", "r2": full},
                         {"setting": "drop_traps", "r2": reduced,
                          "delta": reduced - full}])
