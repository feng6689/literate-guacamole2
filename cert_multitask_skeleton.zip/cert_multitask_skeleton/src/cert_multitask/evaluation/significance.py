# -*- coding: utf-8 -*-
"""评估 · 统计显著性检验（部分实现）。"""
from __future__ import annotations

import numpy as np
from typing import Any

try:
    from scipy import stats
except ImportError:
    stats = None

IMPLEMENTATION_STATUS = "partial"
ALPHA = 0.01


def paired_bootstrap(err_a: np.ndarray, err_b: np.ndarray,
                     n_boot: int = 2000) -> dict[str, Any]:
    """配对 bootstrap：差值均值的置信区间与双侧 p 值。"""
    a, b = np.asarray(err_a, float), np.asarray(err_b, float)
    d = a - b
    rng = np.random.default_rng(42)
    boots = np.array([d[rng.integers(0, len(d), len(d))].mean() for _ in range(n_boot)])
    lo, hi = np.quantile(boots, [0.025, 0.975])
    p = float(2 * min((boots >= 0).mean(), (boots <= 0).mean()))
    return {"mean_diff": float(d.mean()), "ci_low": float(lo), "ci_high": float(hi),
            "p_value": p, "significant_at_0_01": bool(p < ALPHA)}


def diebold_mariano(err_a: np.ndarray, err_b: np.ndarray) -> dict[str, Any]:
    """DM 检验：用差值序列的长期方差做正态近似（此处以样本方差近似）。"""
    d = np.asarray(err_a, float) - np.asarray(err_b, float)
    n = len(d)
    var = float(np.var(d, ddof=1)) / n
    dm = float(d.mean() / np.sqrt(var + 1e-12))
    p = float(2 * (1 - stats.norm.cdf(abs(dm)))) if stats else float("nan")
    return {"dm_stat": dm, "p_value": p, "significant_at_0_01": bool(p < ALPHA)}
