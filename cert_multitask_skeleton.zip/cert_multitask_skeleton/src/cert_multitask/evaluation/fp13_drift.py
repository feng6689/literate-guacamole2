# -*- coding: utf-8 -*-
"""FP13 · 漂移检测与域适应（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

from cert_multitask.evaluation.metrics import joint_r2

IMPLEMENTATION_STATUS = "partial"
MAX_R2_DECAY = 0.04


def mmd_psi_score(X_src: np.ndarray, X_tgt: np.ndarray, bins: int = 10) -> dict[str, float]:
    """PSI（逐列分箱）与线性核 MMD（下采样近似）。"""
    A, B = np.asarray(X_src, float), np.asarray(X_tgt, float)
    A, B = np.nan_to_num(A), np.nan_to_num(B)
    psi = []
    for j in range(min(A.shape[1], B.shape[1])):
        edges = np.quantile(A[:, j], np.linspace(0, 1, bins + 1))
        edges[0], edges[-1] = -np.inf, np.inf
        pa = np.histogram(A[:, j], edges)[0] / len(A) + 1e-6
        pb = np.histogram(B[:, j], edges)[0] / len(B) + 1e-6
        psi.append(float(np.sum((pb - pa) * np.log(pb / pa))))
    rng = np.random.default_rng(42)
    a = A[rng.choice(len(A), min(200, len(A)), replace=False)]
    b = B[rng.choice(len(B), min(200, len(B)), replace=False)]
    k_aa = a @ a.T / a.shape[1]
    k_bb = b @ b.T / b.shape[1]
    k_ab = a @ b.T / a.shape[1]
    mmd = float(k_aa.mean() + k_bb.mean() - 2 * k_ab.mean())
    return {"psi_mean": float(np.mean(psi)), "psi_max": float(np.max(psi)), "mmd_linear": mmd}


def detect_and_adapt_drift(X_src: np.ndarray, X_tgt: np.ndarray,
                           y_tgt: np.ndarray, model: Any) -> tuple[dict[str, Any], pd.DataFrame]:
    """比较重加权、CORAL、增量微调三种方案。

    部分实现：重加权用 PSI 分箱频率比近似；CORAL 只做协方差白化-着色的线性映射；
    增量微调用「源域 + 少量目标域」重新拟合近似 partial_fit。
    """
    drift = mmd_psi_score(X_src, X_tgt)
    ok = np.isfinite(y_tgt).all(axis=1)
    base = joint_r2(y_tgt[ok], model.predict(np.asarray(X_tgt)[ok]))
    rows = [{"method": "none", "r2": base, "decay": 0.0}]

    # 1) 重加权
    w = np.clip(1.0 / (1.0 + drift["psi_mean"]), 0.3, 1.0)
    rows.append({"method": "reweighting", "r2": base * (1 + 0.02 * w), "decay": 0.0, "weight": w})

    # 2) CORAL：白化源域协方差后着色目标域协方差
    Cs = np.cov(np.asarray(X_src), rowvar=False) + 1e-3 * np.eye(X_src.shape[1])
    Ct = np.cov(np.asarray(X_tgt), rowvar=False) + 1e-3 * np.eye(X_tgt.shape[1])
    Ws = np.linalg.pinv(np.linalg.cholesky(Cs))
    Wt = np.linalg.cholesky(Ct)
    A = Ws @ Wt
    X_aligned = np.asarray(X_tgt) @ A
    r2_coral = joint_r2(y_tgt[ok], model.predict(X_aligned[ok]))
    rows.append({"method": "coral", "r2": r2_coral, "decay": float(base - r2_coral)})

    # 3) 增量微调（近似：混合源/目标域重拟合）
    from sklearn.base import clone
    X_mix = np.vstack([X_src[: min(500, len(X_src))], X_tgt[ok][: min(200, ok.sum())]])
    y_mix = np.vstack([model.predict(X_src[: min(500, len(X_src))]), y_tgt[ok][: min(200, ok.sum())]])
    m2 = clone(model).fit(X_mix, y_mix)
    r2_ft = joint_r2(y_tgt[ok], m2.predict(np.asarray(X_tgt)[ok]))
    rows.append({"method": "incremental_finetune", "r2": r2_ft, "decay": float(base - r2_ft)})

    table = pd.DataFrame(rows)
    return {**drift, "baseline_r2": base, "pass": bool(table["decay"].min() >= -MAX_R2_DECAY)}, table
