# -*- coding: utf-8 -*-
"""评估 · 指标计算（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

IMPLEMENTATION_STATUS = "partial"


def joint_r2(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """按样本量加权的联合 R²：1 - Σ_t SSE_t / Σ_t SST_t。"""
    y, p = np.asarray(y_true, float), np.asarray(y_pred, float)
    ok = np.isfinite(y) & np.isfinite(p)
    sse = np.nansum(np.where(ok, (y - p) ** 2, 0.0))
    sst = np.nansum(np.where(ok, (y - np.nanmean(y, axis=0)) ** 2, 0.0))
    return float(1 - sse / (sst + 1e-12))


def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray,
                    intervals: Any = None, n_boot: int = 400) -> dict[str, float]:
    """两目标 R²、联合 R²、MAE、pinball loss、覆盖率与 bootstrap 95% 置信区间。"""
    y, p = np.asarray(y_true, float), np.asarray(y_pred, float)
    ok = np.isfinite(y) & np.isfinite(p)
    rows = np.flatnonzero(ok.all(axis=1))
    m: dict[str, float] = {
        "r2_written": joint_r2(y[rows, 0:1], p[rows, 0:1]),
        "r2_practical": joint_r2(y[rows, 1:2], p[rows, 1:2]),
        "r2_joint": joint_r2(y, p),
        "mae_joint": float(np.nanmean(np.abs(y[ok] - p[ok]))),
        "n_used": int(len(rows)),
    }
    if intervals is not None:
        lo, hi = intervals
        cover = np.mean((y[ok] >= lo[ok]) & (y[ok] <= hi[ok]))
        m["coverage"] = float(cover)
        q = 0.05
        m["pinball_loss"] = float(np.nanmean(np.maximum(q * (y[ok] - lo[ok]), (q - 1) * (y[ok] - lo[ok]))))
    rng = np.random.default_rng(42)
    idx = np.flatnonzero(ok.all(axis=1))
    boots = [joint_r2(y[idx][b], p[idx][b])
             for b in (rng.integers(0, len(idx), len(idx)) for _ in range(min(n_boot, 200)))]
    m["r2_joint_ci_low"], m["r2_joint_ci_high"] = [float(x) for x in np.quantile(boots, [0.025, 0.975])]
    return m
