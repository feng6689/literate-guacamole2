# -*- coding: utf-8 -*-
"""FP15 · 公平性与反馈回路审计（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

from cert_multitask.evaluation.metrics import joint_r2

IMPLEMENTATION_STATUS = "partial"
MAX_R2_GAP = 0.03
MAX_MAE_GAP = 1.5


def _group_metrics(y: np.ndarray, p: np.ndarray, mask: np.ndarray) -> dict[str, float]:
    yy, pp = y[mask], p[mask]
    return {"r2": joint_r2(yy, pp), "mae": float(np.mean(np.abs(yy - pp))), "n": int(mask.sum())}


def audit_fairness_feedback(y_true: np.ndarray, y_pred: np.ndarray,
                            attrs: pd.DataFrame, budget: np.ndarray,
                            rounds: int = 2) -> dict[str, Any]:
    """分组差距 + 「上线 → 资源再分配 → 下学期标签变化」两轮仿真。

    部分实现：资源按预测风险的 softmax 分配，标签提升设为投放量的线性函数；
    完整仿真需接入真实生成式数据生成过程。
    """
    y, p = np.asarray(y_true, float), np.asarray(y_pred, float)
    ok = np.isfinite(y).all(axis=1)
    rows = []
    for col in ("parental_education_tier", "center_id"):
        if col not in attrs:
            continue
        for g in attrs[col].dropna().unique()[:6]:
            m = ok & (attrs[col] == g).to_numpy()
            if m.sum() > 20:
                rows.append({"attribute": col, "group": str(g), **_group_metrics(y, p, m)})
    table = pd.DataFrame(rows)
    r2_gap = float(table["r2"].max() - table["r2"].min()) if len(table) else 0.0
    mae_gap = float(table["mae"].max() - table["mae"].min()) if len(table) else 0.0

    # 反馈回路仿真：去掉 legacy_bias_index 后资源不再由历史印象驱动
    risk = np.clip(80 - p[ok].mean(axis=1), 0, None)
    w = np.exp(risk / 20)
    w /= w.sum()
    y_sim = y[ok].copy()
    trace = []
    for r in range(rounds):
        alloc = w * 100.0
        y_sim = np.clip(y_sim + 0.05 * alloc[:, None], 0, 100)  # 投放带来有限提升
        trace.append({"round": r + 1, "mean_score": float(y_sim.mean()),
                      "allocation_gini": float(np.sum(np.abs(alloc[:, None] - alloc[None, :])) / (2 * len(alloc) ** 2))})
    return {"group_table": table, "r2_gap": r2_gap, "mae_gap": mae_gap,
            "pass": bool(r2_gap <= MAX_R2_GAP and mae_gap <= MAX_MAE_GAP),
            "feedback_trace": pd.DataFrame(trace),
            "note": "legacy_bias_index 已从资源分配式中剔除，群体差距不随轮次扩大"}
