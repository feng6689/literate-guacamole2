# -*- coding: utf-8 -*-
"""FP06 · 风险分层与 ARI（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.metrics import adjusted_rand_score, cohen_kappa_score, confusion_matrix
except ImportError:
    adjusted_rand_score = cohen_kappa_score = confusion_matrix = None

IMPLEMENTATION_STATUS = "partial"


def assign_risk_tiers(y_pred: np.ndarray, lower: np.ndarray,
                      cfg: dict[str, Any] | None = None) -> np.ndarray:
    """双阈值 4 级：0 低风险 / 1 中风险 / 2 高风险 / 3 高风险但高不确定。"""
    cfg = cfg or {}
    hi, mid = float(cfg.get("low_risk_cut", 70)), float(cfg.get("mid_risk_cut", 55))
    wide_cut = float(cfg.get("uncertainty_cut", 8.0))
    p = np.asarray(y_pred, float)
    lo = np.asarray(lower, float)
    score = p.mean(axis=1)
    width = (p - lo).mean(axis=1)
    tier = np.where(score >= hi, 0, np.where(score >= mid, 1, 2))
    tier = np.where((score < mid) & (width > wide_cut), 3, tier)
    return tier.astype(int)


def score_tiers(y_tier: np.ndarray, advisor_tier: np.ndarray) -> dict[str, Any]:
    """计算 ARI、二次加权 Kappa、混淆矩阵与跨两级跳变率。"""
    a, b = np.asarray(advisor_tier, int), np.asarray(y_tier, int)
    out = {
        "ari": float(adjusted_rand_score(a, b)),
        "quadratic_kappa": float(cohen_kappa_score(a, b, weights="quadratic")),
        "confusion_matrix": confusion_matrix(a, b, labels=[0, 1, 2, 3]).tolist(),
        "jump_ge_2_rate": float(np.mean(np.abs(a - b) >= 2)),
    }
    out["pass"] = out["ari"] >= 0.72 and out["jump_ge_2_rate"] < 0.05
    return out
