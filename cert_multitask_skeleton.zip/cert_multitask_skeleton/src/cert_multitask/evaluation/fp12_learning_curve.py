# -*- coding: utf-8 -*-
"""FP12 · 学习曲线与偏差方差诊断（部分实现：只产出曲线数据，绘图交 visualization）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.base import clone
    from sklearn.metrics import mean_absolute_error
except ImportError:
    clone = mean_absolute_error = None

from cert_multitask.evaluation.metrics import joint_r2

IMPLEMENTATION_STATUS = "partial"


def plot_learning_curves(model: Any, X: np.ndarray, y: np.ndarray,
                         groups: np.ndarray, centers: Any = None,
                         terms: Any = None) -> pd.DataFrame:
    """三条曲线：按唯一学员数 / 留一中心外推 / 按学期滚动。

    部分实现：留一中心与滚动曲线复用 groups 与 terms 做近似分组，未做完整外推协议。
    """
    X, y = np.asarray(X, float), np.asarray(y, float)
    groups = np.asarray(groups)
    ok = np.isfinite(y).all(axis=1)
    uniq = np.unique(groups[ok])
    rows = []
    for frac in (0.2, 0.4, 0.6, 0.8, 1.0):
        chosen = set(uniq[: max(1, int(len(uniq) * frac))])
        tr = ok & np.isin(groups, list(chosen))
        va = ok & ~np.isin(groups, list(chosen))
        if tr.sum() < 10 or va.sum() < 5:
            continue
        m = clone(model).fit(X[tr], y[tr])
        p = m.predict(X[va])
        rows.append({"curve": "by_unique_students", "x": int(len(chosen)),
                     "mae": float(mean_absolute_error(y[va], p)), "r2": joint_r2(y[va], p)})
    if centers is not None:
        for c in np.unique(centers)[:3]:
            tr, va = ok & (centers != c), ok & (centers == c)
            if tr.sum() and va.sum():
                m = clone(model).fit(X[tr], y[tr])
                p = m.predict(X[va])
                rows.append({"curve": "leave_one_center_out", "x": int(c),
                             "mae": float(mean_absolute_error(y[va], p)), "r2": joint_r2(y[va], p)})
    if terms is not None:
        for t in np.unique(terms)[1:4]:
            tr, va = ok & (terms < t), ok & (terms == t)
            if tr.sum() and va.sum():
                m = clone(model).fit(X[tr], y[tr])
                p = m.predict(X[va])
                rows.append({"curve": "rolling_term", "x": int(t),
                             "mae": float(mean_absolute_error(y[va], p)), "r2": joint_r2(y[va], p)})
    return pd.DataFrame(rows)


def diagnose_bias_variance_drift(curves: pd.DataFrame) -> dict[str, Any]:
    """区分高偏差 / 高方差 / 分布漂移。"""
    main = curves[curves["curve"] == "by_unique_students"]
    gap = float(main["r2"].max() - main["r2"].min())
    plateau = bool(len(main) > 2 and main["r2"].iloc[-1] - main["r2"].iloc[-2] < 0.005)
    out = {"r2_gap": gap, "plateau": plateau, "diagnosis": [], "recommendations": []}
    if plateau and main["r2"].max() < 0.90:
        out["diagnosis"].append("高偏差：曲线早平台且上限偏低")
        out["recommendations"] += ["特征扩展（交互项 / 低秩嵌入）", "放宽 KNN 的 k 或用集成"]
    elif plateau:
        out["diagnosis"].append("性能平台：偏差方差已平衡，剩余误差来自标签噪声/删失")
        out["recommendations"] += ["标签去偏与异方差建模（FP14）", "堆叠集成（FP16）"]
    else:
        out["diagnosis"].append("高方差：曲线仍在上升，增加样本有效")
        out["recommendations"] += ["扩大训练折", "加强分组正则"]
    if "leave_one_center_out" in set(curves["curve"]):
        loco = curves[curves["curve"] == "leave_one_center_out"]["r2"].min()
        if loco < main["r2"].max() - 0.08:
            out["diagnosis"].append("分布漂移：留一中心外推显著下降")
            out["recommendations"].append("域适应（FP13 的 CORAL / 重加权）")
    return out


def verify_recommendation(cfg: dict[str, Any] | None = None) -> pd.DataFrame:
    """实验验证至少一条改进建议。

    部分实现：这里给出建议与预期增益的占位表，真实 A/B 实验需接入训练流程后运行。
    """
    cfg = cfg or {}
    return pd.DataFrame([
        {"recommendation": "特征扩展（交互嵌入 16 维）", "expected_r2_gain": 0.012,
         "status": "pending_experiment"},
        {"recommendation": "堆叠集成", "expected_r2_gain": 0.008, "status": "pending_experiment"},
        {"recommendation": "CORAL 域适应", "expected_drift_recovery": 0.030, "status": "pending_experiment"},
    ])
