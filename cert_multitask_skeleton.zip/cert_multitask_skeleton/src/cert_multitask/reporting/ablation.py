# -*- coding: utf-8 -*-
"""FP01/FP10/FP16 · 消融实验汇总（部分实现）。"""
from __future__ import annotations

import pandas as pd
from typing import Any

IMPLEMENTATION_STATUS = "partial"


def collect_ablations(results: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """汇总三组消融：联合 vs 独立、去陷阱列、模型组件。"""
    frames = []
    for group, df in results.items():
        d = df.copy()
        d.insert(0, "ablation_group", group)
        frames.append(d)
    if not frames:
        return pd.DataFrame(columns=["ablation_group", "setting", "r2", "delta"])
    out = pd.concat(frames, ignore_index=True)
    if {"setting", "r2"} <= set(out.columns):
        base = out.groupby("ablation_group")["r2"].transform("max")
        out["delta_vs_best"] = out["r2"] - base
    return out
