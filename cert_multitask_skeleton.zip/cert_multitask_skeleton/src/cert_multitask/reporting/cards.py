# -*- coding: utf-8 -*-
"""FP16 · 数据卡与模型卡（部分实现）。"""
from __future__ import annotations

import json
import os
import pandas as pd
from typing import Any

IMPLEMENTATION_STATUS = "partial"


def build_data_card(spec: dict[str, Any], quality: dict[str, Any]) -> dict[str, Any]:
    """生成数据卡：生成式公式、缺失机制、删失与考评员偏差声明。"""
    return {
        "name": "跨区域技能认证联盟 · 学员面板",
        "n_records": spec.get("n_records", 3898),
        "n_unique_students": spec.get("n_unique_students", 1400),
        "structure": "学员 × 认证模块面板，同一 student_id 跨 1-4 模块重复出现",
        "sources": ["enrollment", "interaction_logs", "assessment_records"],
        "interaction_matrix": {"n_resources": spec.get("n_resources", 320),
                               "density_max": spec.get("interaction_density_max", 0.06)},
        "defects": {"right_censoring": "written_exam_score 约 5% 缺考不可观测",
                    "rater_bias": "practical_assessment_score 含 3 名考评员系统偏差",
                    "mnar": ["weekly_study_hours", "prior_term_grade"],
                    "pseudo_correlation": "legacy_bias_index 与目标伪相关，禁止用于决策"},
        "quality": quality,
        "forbidden_features": ["rater_id", "scored_at", "retake_score", "post_exam_survey"],
    }


def build_model_card(cfg: dict[str, Any], results: dict[str, Any]) -> dict[str, Any]:
    """生成模型卡：切分、指标、公平性、漂移与局限。"""
    return {
        "task": "多输出回归 + 90% 条件区间",
        "targets": ["written_exam_score", "practical_assessment_score"],
        "split": cfg.get("split", "walk_forward_grouped"),
        "leakage_controls": ["时间滚动切分", "student_id 分组互斥", "逐折重拟合预处理",
                             "断言 transformer 参数冻结"],
        "metrics": results,
        "thresholds": cfg.get("metrics", {}),
        "fairness": results.get("fairness", "见 FP15 输出"),
        "drift": results.get("drift", "见 FP13 输出"),
        "limitations": ["部分实现，未做端到端联调", "右删失样本不参与训练",
                        "多输出 GP 用独立 GP 近似"],
    }


def write_cards(cards: dict[str, Any], outdir: str = "outputs/reports") -> str:
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, "cards.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cards, f, ensure_ascii=False, indent=2, default=str)
    return path
