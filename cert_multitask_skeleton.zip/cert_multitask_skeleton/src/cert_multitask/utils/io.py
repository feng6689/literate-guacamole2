# -*- coding: utf-8 -*-
"""工具 · 路径与序列化（完整实现）。"""
from __future__ import annotations

import os
import pickle
from typing import Any

try:
    import yaml
except ImportError:
    yaml = None

IMPLEMENTATION_STATUS = "partial"
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_yaml(path: str) -> dict[str, Any]:
    """读取配置；未安装 PyYAML 时报错并给出安装提示。"""
    if yaml is None:
        raise RuntimeError("需要 PyYAML：pip install pyyaml")
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_artifact(obj: Any, path: str) -> None:
    """保存产物到本地（pickle / json 按扩展名选择）。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if path.endswith(".json"):
        import json
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, default=str)
    else:
        with open(path, "wb") as f:
            pickle.dump(obj, f)
