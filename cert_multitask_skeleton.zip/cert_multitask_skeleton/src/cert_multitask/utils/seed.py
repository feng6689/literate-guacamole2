# -*- coding: utf-8 -*-
"""约束 8 · 可复现性（完整实现）。"""
from __future__ import annotations

import os
import random
from typing import Any

import numpy as np

IMPLEMENTATION_STATUS = "partial"


def set_global_seed(seed: int = 42) -> None:
    """固定 python / numpy 随机种子并关闭非确定性哈希扰动。"""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)


def get_rng(seed: int = 42) -> Any:
    """返回独立 RNG，避免各模块共享全局状态。"""
    return np.random.default_rng(seed)
