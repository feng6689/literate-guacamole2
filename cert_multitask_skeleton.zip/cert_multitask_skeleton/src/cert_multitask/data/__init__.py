# -*- coding: utf-8 -*-
"""data 包 · 项目骨架（无实现）。"""
