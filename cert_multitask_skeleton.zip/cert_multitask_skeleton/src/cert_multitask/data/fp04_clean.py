# -*- coding: utf-8 -*-
"""FP04 · 丢弃样本与特征（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

IMPLEMENTATION_STATUS = "partial"
MIN_RETENTION = 0.97


def clean_dataset(bundle: dict[str, Any], spec: dict[str, Any]) -> dict[str, Any]:
    """清洗重复记录、逻辑矛盾与越界值；MNAR 缺失不删行。"""
    df = bundle["enrollment"].copy()
    assess = bundle["assessment"].copy()
    n0 = len(df)
    dropped: dict[str, int] = {}

    dup = df.duplicated(subset=["student_id", "term_id"], keep="first")
    dropped["duplicate_key"] = int(dup.sum())

    # 逻辑矛盾：出勤极高、自习极低却给出接近满分的历史成绩
    contradiction = (
        (df["attendance_rate"] > 98) & (df["weekly_study_hours"] < 1.0)
        & (df["prior_term_grade"] > 95)
    ).fillna(False)
    dropped["logical_contradiction"] = int(contradiction.sum())

    out_of_range = pd.Series(False, index=df.index)
    for col, (lo, hi) in {
        "attendance_rate": (10, 100), "prior_term_grade": (0, 100),
        "sleep_hours_avg": (3, 12), "commute_time_minutes": (5, 120),
    }.items():
        v = pd.to_numeric(df[col], errors="coerce")
        out_of_range |= (v < lo) | (v > hi)
    dropped["out_of_range"] = int(out_of_range.sum())

    keep = ~(dup | contradiction | out_of_range)
    df, assess = df.loc[keep].reset_index(drop=True), assess.loc[keep].reset_index(drop=True)
    retention = len(df) / max(n0, 1)
    if retention < MIN_RETENTION:
        raise ValueError(f"保留率 {retention:.3f} 低于 {MIN_RETENTION}")

    out = dict(bundle)
    out["enrollment"], out["assessment"] = df, assess
    out["quality_report"] = {"n_input": n0, "n_output": len(df),
                             "retention": retention, "dropped": dropped,
                             "mnar_rows_deleted": 0}
    return out


def diagnose_missingness(frame: pd.DataFrame) -> pd.DataFrame:
    """逐列判定缺失机制。

    部分实现：用「缺失指示与观测值的相关」近似区分 MCAR / MAR / MNAR；
    严格的 Little 检验与缺失机制模型留待完整实现。
    """
    rows = []
    for col in frame.columns:
        miss = frame[col].isna()
        rate = float(miss.mean())
        if rate == 0:
            mechanism = "none"
        elif frame[col].dtype == object:
            mechanism = "MAR/structural"
        else:
            obs = pd.to_numeric(frame[col], errors="coerce")
            corr = abs(float(np.corrcoef(miss.astype(float), obs.fillna(obs.mean()))[0, 1])) if obs.notna().sum() > 2 else 0.0
            mechanism = "MNAR" if corr > 0.10 else "MCAR/MAR"
        rows.append({"column": col, "missing_rate": round(rate, 4), "mechanism": mechanism})
    return pd.DataFrame(rows)


def sensitivity_analysis(bundle: dict[str, Any], strategies: list[str] | None = None) -> pd.DataFrame:
    """比较不同缺失处理策略对目标均值的影响。"""
    strategies = strategies or ["complete_case", "median_impute", "group_median_impute"]
    df, y = bundle["enrollment"], bundle["assessment"]["practical_assessment_score"].to_numpy()
    rows = []
    for s in strategies:
        if s == "complete_case":
            mask = df[["weekly_study_hours", "prior_term_grade"]].notna().all(axis=1).to_numpy()
        elif s == "median_impute":
            mask = np.ones(len(df), dtype=bool)
        else:
            mask = np.ones(len(df), dtype=bool)
        rows.append({"strategy": s, "n_used": int(mask.sum()),
                     "mean_practical": float(np.nanmean(y[mask])),
                     "delta_vs_full": float(np.nanmean(y[mask]) - np.nanmean(y))})
    return pd.DataFrame(rows)
