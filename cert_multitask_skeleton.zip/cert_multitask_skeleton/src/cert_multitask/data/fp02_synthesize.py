# -*- coding: utf-8 -*-
"""FP02 · NumPy 合成与用户-物品交互矩阵（部分实现）。

生成式（四层复杂度）：
  ability = linear_main + low_rank_latent + nonlinear_interaction
  y = f(ability) + heteroscedastic_noise + rater_bias，written 侧再做右删失
  legacy_bias_index 只与 edu / ability 相关，不进入 y 的生成式 —— 因此它对目标是
  混淆式伪相关：历史数据里看起来有预测力，部署后会自我强化群体偏差。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any
from scipy import sparse

IMPLEMENTATION_STATUS = "partial"

N_RECORDS = 3898
N_RESOURCES = 320
MAX_DENSITY = 0.06
GENERATION_LAYERS = ("linear_main", "low_rank_latent", "nonlinear_interaction", "heteroscedastic_noise")
MOTIVATION_LEVELS = ("low", "moderate", "high", "very_high", "not_disclosed")
EDU_TIERS = ("none", "secondary", "vocational", "undergraduate", "postgraduate")

FORMULA = (
    "ability = 0.34*u(study) + 0.26*u(attend) + 0.30*u(prior) + 0.10*u(tutoring)\n"
    "        - 0.06*u(commute)                                  [linear_main]\n"
    "        + 0.35*z(Z @ w_latent)                             [low_rank_latent]\n"
    "        + 0.18*u(study)*u(attend) + 0.08*sin(3*u(sleep))   [nonlinear_interaction]\n"
    "y_written   = 38 + 11*ability + N(0, 2.0+1.5*u(commute))  [heteroscedastic]\n"
    "y_practical = 42 +  9*ability + 0.6*(y_written-38)\n"
    "            + rater_bias[rater_id] + N(0, 1.2+0.8*u(study))\n"
    "y_written[~5%] = NaN   # 右删失，禁止填 0/均值\n"
    "legacy_bias_index = 0.45*rank(edu)/4 + 0.25*u(ability) + N(0,0.08)  # 不入 y"
)


def _unit(a: np.ndarray) -> np.ndarray:
    """把任意向量压到 [0, 1]，仅用于生成时稳定量纲。"""
    a = np.asarray(a, dtype=float)
    return (a - np.nanmin(a)) / (np.nanmax(a) - np.nanmin(a) + 1e-9)


def build_interaction_matrix(logs: pd.DataFrame, n_resources: int) -> Any:
    """由隐式反馈日志构建 CSR 稀疏交互矩阵（密度低于 6%）。"""
    mat = sparse.coo_matrix(
        (logs["weight"].to_numpy(float),
         (logs["row_idx"].to_numpy(int), logs["resource_id"].to_numpy(int))),
        shape=(int(logs["row_idx"].max()) + 1, n_resources),
    ).tocsr()
    mat.sum_duplicates()
    return mat


def inject_mnar_missing(frame: pd.DataFrame, spec: dict[str, Any], rng: Any) -> pd.DataFrame:
    """按「值越低越不填」注入非随机缺失，首模块学员缺 prior_term_grade。"""
    out = frame.copy()
    p = np.clip(0.16 - 0.14 * _unit(out["weekly_study_hours"].to_numpy()), 0.01, 0.20)
    out.loc[rng.random(len(out)) < p, "weekly_study_hours"] = np.nan
    first = out["is_first_module"].to_numpy(bool)
    out.loc[first, "prior_term_grade"] = np.nan
    out["motivation_level"] = out["motivation_level"].astype(object)
    undisclosed = rng.random(len(out)) < 0.04
    out.loc[undisclosed, "motivation_level"] = "not_disclosed"
    return out


def inject_label_defects(y: np.ndarray, spec: dict[str, Any], rng: Any) -> dict[str, Any]:
    """注入右删失、考评员系统偏差与异方差噪声。"""
    n = len(y)
    rater_id = rng.integers(0, int(spec.get("n_raters", 3)), size=n)
    rater_bias = np.array([-1.8, 0.4, 2.1])[rater_id]
    sigma_w = 2.0 + 1.5 * _unit(np.arange(n) / max(n, 1))
    sigma_p = 1.2 + 0.8 * rng.random(n)
    y_obs = y.copy()
    y_obs[:, 0] += rng.normal(0, sigma_w, n)
    y_obs[:, 1] += rater_bias + rng.normal(0, sigma_p, n)
    censor = rng.random(n) < float(spec.get("censor_rate", 0.05))
    y_obs[censor, 0] = np.nan  # 右删失：不可观测，不做填充
    return {"y_observed": y_obs, "censor_mask": censor,
            "rater_id": rater_id, "rater_bias_table": {"0": -1.8, "1": 0.4, "2": 2.1}}


def synthesize_dataset(spec: dict[str, Any], seed: int = 42) -> dict[str, Any]:
    """生成三张源表与稀疏交互矩阵；同 seed 完全可复现。"""
    rng = np.random.default_rng(seed)
    n = int(spec.get("n_records", N_RECORDS))
    n_students = int(spec.get("n_unique_students", 1400))
    n_centers = int(spec.get("n_centers", 7))
    n_terms = int(spec.get("n_terms", 6))
    n_res = int(spec.get("n_resources", N_RESOURCES))

    # 面板结构：每名学员重复 1-4 个模块
    reps = rng.integers(1, 5, size=n_students)
    student_id = np.repeat(np.arange(n_students), reps)
    if len(student_id) < n:
        student_id = np.concatenate([student_id, rng.integers(0, n_students, n - len(student_id))])
    student_id = student_id[:n]

    study = np.clip(rng.normal(18, 8, n), 0.5, 45.0)
    attend = np.clip(rng.normal(82, 14, n), 10.0, 100.0)
    prior = np.clip(rng.normal(68, 16, n), 0.0, 100.0)
    tutoring = rng.poisson(4.0, n).clip(0, 30)
    tutoring[rng.random(n) < 0.22] = 0  # 零膨胀
    sleep = np.clip(rng.normal(7.4, 1.3, n), 3.0, 12.0) + rng.normal(0, 0.4, n)
    sleep = np.clip(sleep, 3.0, 12.0)
    extracurricular = np.clip(rng.gamma(2.0, 2.0, n), 0.0, 20.0)
    commute = np.clip(rng.lognormal(3.4, 0.6, n), 5.0, 120.0)
    commute[rng.random(n) < 0.03] *= 1.8  # 极端离群
    commute = np.clip(commute, 5.0, 120.0)

    Z = rng.normal(size=(n, 5))
    latent = Z @ np.array([0.9, 0.6, 0.4, 0.25, 0.15])
    latent = (latent - latent.mean()) / (latent.std() + 1e-9)
    ability = (
        0.34 * _unit(study) + 0.26 * _unit(attend) + 0.30 * _unit(prior)
        + 0.10 * _unit(tutoring) - 0.06 * _unit(commute)   # 线性主效应
        + 0.35 * latent                                      # 低秩潜在因子
        + 0.18 * _unit(study) * _unit(attend)                # 非线性交互
        + 0.08 * np.sin(3 * _unit(sleep))
    )
    y_latent = np.column_stack([38 + 11 * ability, 42 + 9 * ability])
    y_latent[:, 1] += 0.6 * (y_latent[:, 0] - 38)  # 目标间非线性耦合

    defects = inject_label_defects(y_latent, spec, rng)
    y_obs = np.clip(defects["y_observed"], 0.0, 100.0)

    motivation = rng.choice(MOTIVATION_LEVELS, size=n, p=[0.18, 0.34, 0.32, 0.12, 0.04])
    edu = rng.choice(EDU_TIERS, size=n, p=[0.08, 0.34, 0.16, 0.30, 0.12])
    edu_rank = np.array([EDU_TIERS.index(e) for e in edu], dtype=float)
    legacy = np.clip(0.45 * edu_rank / 4 + 0.25 * _unit(ability) + rng.normal(0, 0.08, n), 0, 1)

    enrollment = pd.DataFrame({
        "student_id": student_id,
        "center_id": rng.integers(0, n_centers, n),
        "term_id": rng.integers(0, n_terms, n),
        "cohort_id": rng.integers(0, 12, n),
        "is_first_module": rng.random(n) < 0.28,
        "weekly_study_hours": study, "attendance_rate": attend,
        "prior_term_grade": prior, "tutoring_sessions_count": tutoring,
        "sleep_hours_avg": sleep, "motivation_level": motivation,
        "parental_education_tier": edu, "extracurricular_hours": extracurricular,
        "commute_time_minutes": commute, "random_id_noise": rng.random(n),
        "legacy_bias_index": legacy,
    })
    enrollment = inject_mnar_missing(enrollment, spec, rng)

    assessment = pd.DataFrame({
        "written_exam_score": y_obs[:, 0],
        "practical_assessment_score": y_obs[:, 1],
        "rater_id": defects["rater_id"],
        "scored_at": pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0, 180, n), unit="D"),
        "censor_mask": defects["censor_mask"],
    })

    # 稀疏交互矩阵：密度 < 6%
    nnz = int(n * n_res * float(spec.get("interaction_density_max", MAX_DENSITY)) * 0.6)
    logs = pd.DataFrame({
        "row_idx": rng.integers(0, n, nnz),
        "resource_id": rng.integers(0, n_res, nnz),
        "weight": rng.gamma(2.0, 1.5, nnz),
    })
    interaction = build_interaction_matrix(logs, n_res)

    return {
        "enrollment": enrollment, "assessment": assessment,
        "interaction_logs": logs, "interaction": interaction,
        "y_latent": y_latent, "formula": FORMULA,
        "censor_mask": defects["censor_mask"], "rater_bias_table": defects["rater_bias_table"],
        "spec": spec, "seed": seed,
    }
