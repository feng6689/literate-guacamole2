# -*- coding: utf-8 -*-
"""FP02 · 数据契约与三源表校验（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    import yaml
except ImportError:  # 未安装 PyYAML 时给出明确提示
    yaml = None

IMPLEMENTATION_STATUS = "partial"

FORBIDDEN_FEATURES = ("rater_id", "scored_at", "retake_score", "post_exam_survey", "legacy_bias_index")
TARGETS = ("written_exam_score", "practical_assessment_score")
NUMERIC_BOUNDS = {
    "weekly_study_hours": (0.5, 45.0),
    "attendance_rate": (10.0, 100.0),
    "prior_term_grade": (0.0, 100.0),
    "tutoring_sessions_count": (0, 30),
    "sleep_hours_avg": (3.0, 12.0),
    "extracurricular_hours": (0.0, 20.0),
    "commute_time_minutes": (5.0, 120.0),
    "random_id_noise": (0.0, 1.0),
}


def load_schema(path: str) -> dict[str, Any]:
    """读取 YAML 规格。"""
    if yaml is None:
        raise RuntimeError("需要 PyYAML：pip install pyyaml")
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def validate_tables(tables: dict[str, pd.DataFrame], spec: dict[str, Any]) -> dict[str, Any]:
    """校验列名、类型、值域、主键唯一性与禁入模列。

    部分实现：只做列存在性、值域与 NaN 模式检查，未实现完整的主键约束与跨表一致性。
    """
    report: dict[str, Any] = {"tables": {}, "violations": []}
    for name, df in tables.items():
        info = {"n_rows": int(len(df)), "n_cols": int(df.shape[1]),
                "missing_rate": {c: float(df[c].isna().mean()) for c in df.columns}}
        for col, (lo, hi) in NUMERIC_BOUNDS.items():
            if col not in df.columns:
                info.setdefault("absent", []).append(col)
                continue
            vals = pd.to_numeric(df[col], errors="coerce").dropna()
            if len(vals) and (vals.min() < lo - 1e-6 or vals.max() > hi + 1e-6):
                msg = f"{name}.{col} 越界: [{vals.min():.2f}, {vals.max():.2f}]"
                report["violations"].append(msg)
        leaked = [c for c in FORBIDDEN_FEATURES if c in df.columns]
        if leaked:
            info["forbidden_present"] = leaked  # 允许存在于源表，但禁止进设计矩阵
        report["tables"][name] = info
    report["pass"] = len(report["violations"]) == 0
    return report


def assert_no_forbidden_columns(X: pd.DataFrame, spec: dict[str, Any] | None = None) -> None:
    """断言设计矩阵不含任何后验/泄漏列。"""
    forbidden = set(FORBIDDEN_FEATURES)
    if spec:
        forbidden |= set(spec.get("forbidden_columns", []))
    bad = [c for c in X.columns if c in forbidden]
    if bad:
        raise ValueError(f"设计矩阵含禁入模列: {bad}")
