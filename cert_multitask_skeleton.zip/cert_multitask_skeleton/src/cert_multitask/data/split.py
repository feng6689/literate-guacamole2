# -*- coding: utf-8 -*-
"""约束 1-3 · 时序 + 实体双重切分（部分实现）。"""
from __future__ import annotations

import numpy as np
import pandas as pd
from typing import Any

try:
    from sklearn.model_selection import KFold
except ImportError:
    KFold = None

IMPLEMENTATION_STATUS = "partial"
GROUP_KEY = "student_id"
TIME_KEY = "term_id"


def build_walk_forward_splits(frame: pd.DataFrame, cfg: dict[str, Any]) -> list[dict[str, Any]]:
    """按 term_id 滚动前推，且逐折剔除与验证/测试共享 student_id 的训练行。"""
    time_key = cfg.get("time_key", TIME_KEY)
    group_key = cfg.get("group_key", GROUP_KEY)
    min_train = int(cfg.get("min_train_terms", 3))
    purge = int(cfg.get("purge_gap_terms", 1))
    terms = sorted(frame[time_key].unique())
    splits: list[dict[str, Any]] = []
    for i in range(min_train, len(terms) - 1):
        train_terms = set(terms[: max(0, i - purge)])
        valid_term, test_term = terms[i], terms[i + 1]
        t = frame[time_key].isin(train_terms).to_numpy()
        v = (frame[time_key] == valid_term).to_numpy()
        te = (frame[time_key] == test_term).to_numpy()
        g = frame[group_key].to_numpy()
        blocked = set(g[v]) | set(g[te])
        t &= ~np.isin(g, list(blocked))  # 实体泄漏防护
        splits.append({"fold": len(splits), "train_terms": sorted(train_terms),
                       "valid_term": valid_term, "test_term": test_term,
                       "train": np.flatnonzero(t), "valid": np.flatnonzero(v),
                       "test": np.flatnonzero(te), "purged_groups": len(blocked)})
    return splits


def assert_group_disjoint(splits: list[dict[str, Any]], group_key: str) -> None:
    """断言同一分组键不跨训练/验证/测试。"""
    # 部分实现：此处只校验折内索引互斥；跨表 group 校验由调用方传入 frame 后执行
    for s in splits:
        a, b, c = set(s["train"]), set(s["valid"]), set(s["test"])
        if a & b or a & c or b & c:
            raise AssertionError(f"fold {s['fold']} 存在索引重叠")
        if len(a) == 0 or len(c) == 0:
            raise AssertionError(f"fold {s['fold']} 训练/测试为空")


def nested_inner_folds(train_idx: Any, cfg: dict[str, Any], n_splits: int = 3) -> list[Any]:
    """在训练折内部再切折供超参搜索（折中折）。"""
    if KFold is None:
        raise RuntimeError("需要 scikit-learn")
    idx = np.asarray(train_idx)
    return [(idx[tr], idx[va]) for tr, va in KFold(n_splits=n_splits, shuffle=False).split(idx)]
