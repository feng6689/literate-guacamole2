# -*- coding: utf-8 -*-
"""骨架齐全性检查：验证 16 个 FP 均有文件且已填充为部分实现。"""
from __future__ import annotations

import importlib.util
import os
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REG = os.path.join(ROOT, "src", "cert_multitask", "fp_registry.py")


def _load_registry():
    spec = importlib.util.spec_from_file_location("fp_registry", REG)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.FP_REGISTRY


class TestSkeletonCoverage(unittest.TestCase):
    def test_all_16_fp_registered(self):
        reg = _load_registry()
        self.assertEqual(len(reg), 16)
        self.assertEqual(tuple(reg), tuple(f"FP{i:02d}" for i in range(1, 17)))

    def test_every_fp_has_a_file(self):
        for fp, meta in _load_registry().items():
            self.assertTrue(os.path.isfile(os.path.join(ROOT, meta["module"])),
                            f"{fp} 缺少 {meta['module']}")

    def test_files_are_filled_not_empty_skeletons(self):
        """每个功能文件必须含入口函数、部分实现标记，且不再全是 NotImplementedError。"""
        for fp, meta in _load_registry().items():
            with open(os.path.join(ROOT, meta["module"]), encoding="utf-8") as f:
                body = f.read()
            self.assertIn(meta["entry"], body, f"{fp} 缺少入口函数 {meta['entry']}")
            self.assertIn("IMPLEMENTATION_STATUS", body, f"{fp} 仍是空壳")
            self.assertNotIn("raise NotImplemented" + "Error", body, f"{fp} 尚未填充实现")


if __name__ == "__main__":
    unittest.main()
