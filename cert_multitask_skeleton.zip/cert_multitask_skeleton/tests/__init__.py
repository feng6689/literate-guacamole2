# -*- coding: utf-8 -*-
"""tests 包 · 项目骨架（无实现）。"""
