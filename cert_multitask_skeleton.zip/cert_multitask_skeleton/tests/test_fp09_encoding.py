# -*- coding: utf-8 -*-
"""FP09 · 验收测试（部分实现，完整断言待端到端联调后补齐）"""
from __future__ import annotations

import unittest


@unittest.skip("部分实现：FP09 完整验收断言待联调后解除 skip")
class TestNestedEncoding(unittest.TestCase):
    def test_acceptance(self):
        """折内均值与全量均值存在差异，OOF 编码无泄漏"""
        self.assertTrue(True)  # 占位断言


if __name__ == "__main__":
    unittest.main()
